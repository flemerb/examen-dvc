**name**: Flemer  
**first name**: Burkhardt  
**email address**: bflemer@gmail.com  
**DagsHub repository**: https://dagshub.com/flemerb/examen-dvc  